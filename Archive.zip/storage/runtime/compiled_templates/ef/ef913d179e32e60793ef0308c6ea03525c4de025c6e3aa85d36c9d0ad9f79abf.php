<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/field */
class __TwigTemplate_ae6720ae3acc6c095128a7287482b63d76fd36ecc74d83c4f06ba862ca32bb0e extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["labelId"] = (((isset($context["labelId"]) || array_key_exists("labelId", $context))) ? ((isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 1, $this->source); })())) : ((((isset($context["id"]) || array_key_exists("id", $context))) ? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 1, $this->source); })()) . "-label")) : (null))));
        // line 2
        $context["fieldId"] = (((isset($context["fieldId"]) || array_key_exists("fieldId", $context))) ? ((isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 2, $this->source); })())) : ((((isset($context["id"]) || array_key_exists("id", $context))) ? (((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 2, $this->source); })()) . "-field")) : (null))));
        // line 3
        $context["label"] = ((((isset($context["label"]) || array_key_exists("label", $context)) && ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 3, $this->source); })()) != "__blank__"))) ? ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 3, $this->source); })())) : (null));
        // line 4
        $context["siteId"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", []), "getIsMultiSite", [], "method") && (isset($context["siteId"]) || array_key_exists("siteId", $context)))) ? ((isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 4, $this->source); })())) : (null));
        // line 5
        $context["site"] = (((isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 5, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => (isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 5, $this->source); })())], "method")) : (null));
        // line 6
        $context["instructions"] = (((isset($context["instructions"]) || array_key_exists("instructions", $context))) ? ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 6, $this->source); })())) : (null));
        // line 7
        $context["tip"] = (((isset($context["tip"]) || array_key_exists("tip", $context))) ? ((isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 7, $this->source); })())) : (null));
        // line 8
        $context["warning"] = (((isset($context["warning"]) || array_key_exists("warning", $context))) ? ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 8, $this->source); })())) : (null));
        // line 9
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, (((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 9, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 9, $this->source); })()), "app", []), "i18n", []), "getLocaleById", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 9, $this->source); })()), "language", [])], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 9, $this->source); })()), "app", []), "locale", []))), "getOrientation", [], "method");
        // line 10
        $context["translatable"] = (($context["translatable"]) ?? ( !((isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 10, $this->source); })()) === null)));
        // line 11
        $context["errors"] = (((isset($context["errors"]) || array_key_exists("errors", $context))) ? ((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 11, $this->source); })())) : (null));
        // line 12
        $context["fieldClass"] = twig_join_filter($this->extensions['craft\web\twig\Extension']->filterFilter([0 => "field", 1 => (((        // line 14
(isset($context["first"]) || array_key_exists("first", $context)) && (isset($context["first"]) || array_key_exists("first", $context) ? $context["first"] : (function () { throw new RuntimeError('Variable "first" does not exist.', 14, $this->source); })()))) ? ("first") : (null)), 2 => ((        // line 15
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 15, $this->source); })())) ? ("has-errors") : (null)), 3 => (((        // line 16
(isset($context["fieldClass"]) || array_key_exists("fieldClass", $context)) && (isset($context["fieldClass"]) || array_key_exists("fieldClass", $context) ? $context["fieldClass"] : (function () { throw new RuntimeError('Variable "fieldClass" does not exist.', 16, $this->source); })()))) ? ((isset($context["fieldClass"]) || array_key_exists("fieldClass", $context) ? $context["fieldClass"] : (function () { throw new RuntimeError('Variable "fieldClass" does not exist.', 16, $this->source); })())) : (null))]), " ");
        // line 18
        echo "
<div class=\"";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["fieldClass"]) || array_key_exists("fieldClass", $context) ? $context["fieldClass"] : (function () { throw new RuntimeError('Variable "fieldClass" does not exist.', 19, $this->source); })()), "html", null, true);
        echo "\"";
        // line 20
        if ((isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 20, $this->source); })())) {
            echo " id=\"";
            echo twig_escape_filter($this->env, (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 20, $this->source); })()), "html", null, true);
            echo "\"";
        }
        // line 21
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    ";
        // line 22
        if (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 22, $this->source); })()) || (isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 22, $this->source); })()))) {
            // line 23
            echo "        <div class=\"heading\">
            ";
            // line 24
            if ((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 24, $this->source); })())) {
                // line 25
                echo "                <label ";
                if ((isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 25, $this->source); })())) {
                    echo " id=\"";
                    echo twig_escape_filter($this->env, (isset($context["labelId"]) || array_key_exists("labelId", $context) ? $context["labelId"] : (function () { throw new RuntimeError('Variable "labelId" does not exist.', 25, $this->source); })()), "html", null, true);
                    echo "\"";
                }
                if (((isset($context["required"]) || array_key_exists("required", $context)) && (isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 25, $this->source); })()))) {
                    echo " class=\"required\"";
                }
                if (((isset($context["id"]) || array_key_exists("id", $context)) && (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 25, $this->source); })()))) {
                    echo " for=\"";
                    echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 25, $this->source); })()), "html", null, true);
                    echo "\"";
                }
                echo ">";
                // line 26
                echo (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 26, $this->source); })());
                // line 27
                if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new RuntimeError('Variable "translatable" does not exist.', 27, $this->source); })())) {
                    echo " <span class=\"extralight\" data-icon=\"language\" title=\"";
                    echo twig_escape_filter($this->env, (($context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "html", null, true);
                    echo "\"></span>";
                }
                // line 28
                echo "</label>
            ";
            }
            // line 30
            echo "            ";
            if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 30, $this->source); })())) {
                // line 31
                echo "                <div class=\"instructions\">";
                echo $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 31, $this->source); })()), "gfm-comment"), "/&amp;(\\w+);/", "&\$1;");
                echo "</div>
            ";
            }
            // line 33
            echo "        </div>
    ";
        }
        // line 35
        echo "    <div class=\"input ";
        echo twig_escape_filter($this->env, (isset($context["orientation"]) || array_key_exists("orientation", $context) ? $context["orientation"] : (function () { throw new RuntimeError('Variable "orientation" does not exist.', 35, $this->source); })()), "html", null, true);
        if ((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 35, $this->source); })())) {
            echo " errors";
        }
        echo "\">
        ";
        // line 36
        echo (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 36, $this->source); })());
        echo "
    </div>
    ";
        // line 38
        if ((isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 38, $this->source); })())) {
            // line 39
            echo "        <p class=\"notice\">";
            echo $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["tip"]) || array_key_exists("tip", $context) ? $context["tip"] : (function () { throw new RuntimeError('Variable "tip" does not exist.', 39, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;");
            echo "</p>
    ";
        }
        // line 41
        echo "    ";
        if ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 41, $this->source); })())) {
            // line 42
            echo "        <p class=\"warning\">";
            echo $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new RuntimeError('Variable "warning" does not exist.', 42, $this->source); })()), null, true), "/&amp;(\\w+);/", "&\$1;");
            echo "</p>
    ";
        }
        // line 44
        echo "    ";
        $this->loadTemplate("_includes/forms/errorList", "_includes/forms/field", 44)->display(twig_array_merge($context, ["errors" => (isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 44, $this->source); })())]));
        // line 45
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "_includes/forms/field";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 45,  161 => 44,  155 => 42,  152 => 41,  146 => 39,  144 => 38,  139 => 36,  131 => 35,  127 => 33,  121 => 31,  118 => 30,  114 => 28,  108 => 27,  106 => 26,  90 => 25,  88 => 24,  85 => 23,  83 => 22,  76 => 21,  70 => 20,  67 => 19,  64 => 18,  62 => 16,  61 => 15,  60 => 14,  59 => 12,  57 => 11,  55 => 10,  53 => 9,  51 => 8,  49 => 7,  47 => 6,  45 => 5,  43 => 4,  41 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set labelId = (labelId is defined ? labelId : (id is defined ? id~'-label' : null)) %}
{%- set fieldId = (fieldId is defined ? fieldId : (id is defined ? id~'-field' : null)) %}
{%- set label = (label is defined and label != '__blank__' ? label : null) %}
{%- set siteId = ((craft.app.getIsMultiSite() and siteId is defined) ? siteId : null) %}
{%- set site = (siteId ? craft.app.sites.getSiteById(siteId) : null) %}
{%- set instructions = (instructions is defined ? instructions : null) %}
{%- set tip = (tip is defined ? tip : null) %}
{%- set warning = (warning is defined ? warning : null) %}
{%- set orientation = (site ? craft.app.i18n.getLocaleById(site.language) : craft.app.locale).getOrientation() %}
{%- set translatable = translatable ?? (site is not same as(null)) %}
{%- set errors = (errors is defined ? errors : null) -%}
{%- set fieldClass = [
    'field',
    (first is defined and first ? 'first' : null),
    (errors ? 'has-errors' : null),
    (fieldClass is defined and fieldClass ? fieldClass : null)
]|filter|join(' ') %}

<div class=\"{{ fieldClass }}\"
        {%- if fieldId %} id=\"{{ fieldId }}\"{% endif %}
        {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    {% if label or instructions %}
        <div class=\"heading\">
            {% if label %}
                <label {% if labelId %} id=\"{{ labelId }}\"{% endif %}{% if required is defined and required %} class=\"required\"{% endif %}{% if id is defined and id %} for=\"{{ id }}\"{% endif %}>
                    {{- label|raw -}}
                    {%- if translatable %} <span class=\"extralight\" data-icon=\"language\" title=\"{{ translationDescription ?? 'This field is translatable.'|t('app') }}\"></span>{% endif -%}
                </label>
            {% endif %}
            {% if instructions %}
                <div class=\"instructions\">{{ instructions|md('gfm-comment')|replace('/&amp;(\\\\w+);/', '&\$1;')|raw }}</div>
            {% endif %}
        </div>
    {% endif %}
    <div class=\"input {{ orientation }}{% if errors %} errors{% endif %}\">
        {{ input|raw }}
    </div>
    {% if tip %}
        <p class=\"notice\">{{ tip|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;')|raw }}</p>
    {% endif %}
    {% if warning %}
        <p class=\"warning\">{{ warning|md(inlineOnly=true)|replace('/&amp;(\\\\w+);/', '&\$1;')|raw }}</p>
    {% endif %}
    {% include \"_includes/forms/errorList\" with { errors: errors } %}
</div>
", "_includes/forms/field", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/vendor/craftcms/cms/src/templates/_includes/forms/field.html");
    }
}
