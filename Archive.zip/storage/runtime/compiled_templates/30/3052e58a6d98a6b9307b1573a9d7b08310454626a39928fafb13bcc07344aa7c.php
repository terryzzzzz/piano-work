<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/basecp */
class __TwigTemplate_c8c7f1185819a579aaaa347e351e734d60c292b3b866bab620ecdd163486a5b9 extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'foot' => [$this, 'block_foot'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/base";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method")) {
            // line 5
            $context["bodyClass"] = (((((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context)) && (isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 5, $this->source); })()))) ? (((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 5, $this->source); })()) . " ")) : ("")) . "mobile");
        }
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Show", 1 => "Hide"]], "method");
        // line 13
        $context["localeData"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", []), "locale", []);
        // line 14
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["localeData"]) || array_key_exists("localeData", $context) ? $context["localeData"] : (function () { throw new RuntimeError('Variable "localeData" does not exist.', 14, $this->source); })()), "getOrientation", [], "method");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/base", "_layouts/basecp", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_foot($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 17
        echo "    <form id=\"x\" method=\"post\" accept-charset=\"UTF-8\">
        ";
        // line 18
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "
    </form>
    <noscript>
        <div class=\"message-container no-access\">
            <div class=\"pane notice\">
                <p>";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("JavaScript must be enabled to access the Craft CMS Control Panel.", "app"), "html", null, true);
        echo "</p>
            </div>
        </div>
    </noscript>

    ";
        // line 28
        ob_start();
        // line 29
        echo "        // Picture element HTML5 shiv
        document.createElement('picture');
    ";
        Craft::$app->getView()->registerJs(ob_get_clean(), 1);
    }

    public function getTemplateName()
    {
        return "_layouts/basecp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 29,  81 => 28,  73 => 23,  65 => 18,  62 => 17,  58 => 16,  53 => 1,  51 => 14,  49 => 13,  47 => 8,  44 => 5,  42 => 4,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/base\" %}

{# Give the body a .mobile class for mobile devices #}
{% if craft.app.request.isMobileBrowser(true) %}
    {% set bodyClass = (bodyClass is defined and bodyClass ? bodyClass~' ' : '') ~ 'mobile' %}
{% endif %}

{% do view.registerTranslations('app', [
    \"Show\",
    \"Hide\",
]) %}

{% set localeData = craft.app.locale %}
{% set orientation = localeData.getOrientation() %}

{% block foot %}
    <form id=\"x\" method=\"post\" accept-charset=\"UTF-8\">
        {{ csrfInput() }}
    </form>
    <noscript>
        <div class=\"message-container no-access\">
            <div class=\"pane notice\">
                <p>{{ \"JavaScript must be enabled to access the Craft CMS Control Panel.\"|t('app') }}</p>
            </div>
        </div>
    </noscript>

    {% js at head %}
        // Picture element HTML5 shiv
        document.createElement('picture');
    {% endjs %}
{% endblock %}
", "_layouts/basecp", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/vendor/craftcms/cms/src/templates/_layouts/basecp.html");
    }
}
