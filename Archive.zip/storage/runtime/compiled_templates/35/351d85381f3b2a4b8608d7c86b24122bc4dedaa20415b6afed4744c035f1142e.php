<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/editableTable */
class __TwigTemplate_e8fcd0941727f38db53f8c72f976bae2d2fa0b562206987ba0c52274d77ad22c extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'tablecell' => [$this, 'block_tablecell'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["static"] = (($context["static"]) ?? (false));
        // line 2
        $context["cols"] = (($context["cols"]) ?? ([]));
        // line 3
        $context["rows"] = (($context["rows"]) ?? ([]));
        // line 4
        $context["initJs"] = ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 4, $this->source); })()) && (($context["initJs"]) ?? (true)));
        // line 5
        $context["minRows"] = (($context["minRows"]) ?? (null));
        // line 6
        $context["maxRows"] = (($context["maxRows"]) ?? (null));
        // line 7
        $context["staticRows"] = (((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 7, $this->source); })()) || (($context["staticRows"]) ?? (false))) || ((((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 7, $this->source); })()) == 1) && ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 7, $this->source); })()) == 1)) && (twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 7, $this->source); })())) == 1)));
        // line 8
        $context["fixedRows"] = ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 8, $this->source); })()) && (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 8, $this->source); })()) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 8, $this->source); })()) == (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 8, $this->source); })()))) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 8, $this->source); })()) == twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 8, $this->source); })())))));
        // line 9
        echo "
";
        // line 10
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 10, $this->source); })())) {
            // line 11
            echo "    <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 11, $this->source); })()), "html", null, true);
            echo "\" value=\"\">
";
        }
        // line 13
        echo "
<table id=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 14, $this->source); })()), "html", null, true);
        echo "\" class=\"shadow-box editable\"";
        // line 15
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    <thead>
        <tr>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 18, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 19
            switch (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [])) {
                case "time":
                {
                    // line 21
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 21, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\timepicker\\TimepickerAsset"], "method");
                    break;
                }
                case "template":
                {
                    // line 23
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 23, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\vue\\VueAsset"], "method");
                    break;
                }
            }
            // line 25
            echo "                <th scope=\"col\" class=\"";
            (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", []), "html", null, true))) : (print ("")));
            echo "\">";
            // line 26
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", []))) {
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", []), "html", null, true);
            } else {
                echo "&nbsp;";
            }
            // line 27
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", [], "any", true, true)) {
                // line 28
                echo "<span class=\"info\">";
                echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", []));
                echo "</span>";
            }
            // line 30
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['col'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "            ";
        if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 32, $this->source); })())) {
            // line 33
            echo "                <th colspan=\"";
            echo (((isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 33, $this->source); })())) ? (1) : (2));
            echo "\"></th>
            ";
        }
        // line 35
        echo "        </tr>
    </thead>
    <tbody>
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 38, $this->source); })()));
        foreach ($context['_seq'] as $context["rowId"] => $context["row"]) {
            // line 39
            echo "            <tr data-id=\"";
            echo twig_escape_filter($this->env, $context["rowId"], "html", null, true);
            echo "\">
                ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 40, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["colId"] => $context["col"]) {
                // line 41
                echo "                    ";
                $context["cell"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array")) : (null));
                // line 42
                echo "                    ";
                $context["value"] = ((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 42, $this->source); })()), "value", [])) : ((isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 42, $this->source); })())));
                // line 43
                echo "                    ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "heading")) {
                    // line 44
                    echo "                        <th scope=\"row\" class=\"";
                    echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ("")))), "html", null, true);
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 44, $this->source); })());
                    echo "</th>
                    ";
                } elseif ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 45
$context["col"], "type", []) == "html")) {
                    // line 46
                    echo "                        <td class=\"";
                    echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ("")))), "html", null, true);
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 46, $this->source); })());
                    echo "</td>
                    ";
                } else {
                    // line 48
                    echo "                        ";
                    $context["hasErrors"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])) : (false));
                    // line 49
                    echo "                        ";
                    $context["cellName"] = ((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 49, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["colId"]) . "]");
                    // line 50
                    echo "                        ";
                    $context["textual"] = twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []), [0 => "color", 1 => "date", 2 => "email", 3 => "multiline", 4 => "number", 5 => "singleline", 6 => "template", 7 => "time", 8 => "url"]);
                    // line 51
                    echo "                        ";
                    $context["isCode"] = (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", true, true) || (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "color"));
                    // line 52
                    echo "                        <td class=\"";
                    if ((isset($context["textual"]) || array_key_exists("textual", $context) ? $context["textual"] : (function () { throw new RuntimeError('Variable "textual" does not exist.', 52, $this->source); })())) {
                        echo "textual";
                    }
                    echo " ";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true)) {
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", []), "html", null, true);
                    }
                    echo " ";
                    if ((isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 52, $this->source); })())) {
                        echo "code";
                    }
                    echo " ";
                    if ((isset($context["hasErrors"]) || array_key_exists("hasErrors", $context) ? $context["hasErrors"] : (function () { throw new RuntimeError('Variable "hasErrors" does not exist.', 52, $this->source); })())) {
                        echo "error";
                    }
                    echo "\"";
                    if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true)) {
                        echo " width=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">
                            ";
                    // line 53
                    $this->displayBlock('tablecell', $context, $blocks);
                    // line 116
                    echo "                        </td>
                    ";
                }
                // line 118
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['colId'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 119
            echo "                ";
            if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 119, $this->source); })())) {
                // line 120
                echo "                    <td class=\"thin action\"><a class=\"move icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\"></a></td>
                    ";
                // line 121
                if ( !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 121, $this->source); })())) {
                    echo "<td class=\"thin action\"><a class=\"delete icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\"></a></td>";
                }
                // line 122
                echo "                ";
            }
            // line 123
            echo "            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['rowId'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 125
        echo "    </tbody>
</table>
";
        // line 127
        if (( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 127, $this->source); })()) &&  !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 127, $this->source); })()))) {
            // line 128
            echo "    <div class=\"btn add icon\">";
            echo twig_escape_filter($this->env, (((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context))) ? ((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context) ? $context["addRowLabel"] : (function () { throw new RuntimeError('Variable "addRowLabel" does not exist.', 128, $this->source); })())) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Add a row", "app"))), "html", null, true);
            echo "</div>
";
        }
        // line 130
        echo "
";
        // line 131
        if ((isset($context["initJs"]) || array_key_exists("initJs", $context) ? $context["initJs"] : (function () { throw new RuntimeError('Variable "initJs" does not exist.', 131, $this->source); })())) {
            // line 132
            echo "    ";
            $context["jsId"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 132, $this->source); })())]), "js");
            // line 133
            echo "    ";
            $context["jsName"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 133, $this->source); })())]), "js");
            // line 134
            echo "    ";
            $context["jsCols"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 134, $this->source); })()));
            // line 135
            echo "    ";
            $context["defaultValues"] = (($context["defaultValues"]) ?? (null));
            // line 136
            echo "    ";
            ob_start();
            // line 137
            echo "        new Craft.EditableTable(\"";
            echo twig_escape_filter($this->env, (isset($context["jsId"]) || array_key_exists("jsId", $context) ? $context["jsId"] : (function () { throw new RuntimeError('Variable "jsId" does not exist.', 137, $this->source); })()), "html", null, true);
            echo "\", \"";
            echo twig_escape_filter($this->env, (isset($context["jsName"]) || array_key_exists("jsName", $context) ? $context["jsName"] : (function () { throw new RuntimeError('Variable "jsName" does not exist.', 137, $this->source); })()), "html", null, true);
            echo "\", ";
            echo (isset($context["jsCols"]) || array_key_exists("jsCols", $context) ? $context["jsCols"] : (function () { throw new RuntimeError('Variable "jsCols" does not exist.', 137, $this->source); })());
            echo ", {
            defaultValues: ";
            // line 138
            echo (((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 138, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 138, $this->source); })()))) : ("{}"));
            echo ",
            staticRows: ";
            // line 139
            echo (((isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 139, $this->source); })())) ? ("true") : ("false"));
            echo ",
            minRows: ";
            // line 140
            (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 140, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 140, $this->source); })()), "html", null, true))) : (print ("null")));
            echo ",
            maxRows: ";
            // line 141
            (((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 141, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 141, $this->source); })()), "html", null, true))) : (print ("null")));
            echo "
        });
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
    }

    // line 53
    public function block_tablecell($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 54
        switch (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 54, $this->source); })()), "type", [])) {
            case "checkbox":
            {
                // line 56
                $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/editableTable", 56)->display(twig_to_array(["name" =>                 // line 57
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 57, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 58
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "checked" =>  !twig_test_empty(                // line 59
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 59, $this->source); })())), "disabled" =>                 // line 60
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 60, $this->source); })())]));
                break;
            }
            case "color":
            {
                // line 63
                $this->loadTemplate("_includes/forms/color", "_includes/forms/editableTable", 63)->display(twig_to_array(["name" =>                 // line 64
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 64, $this->source); })()), "value" =>                 // line 65
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 65, $this->source); })()), "small" => true, "disabled" =>                 // line 67
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 67, $this->source); })())]));
                break;
            }
            case "date":
            {
                // line 70
                $this->loadTemplate("_includes/forms/date", "_includes/forms/editableTable", 70)->display(twig_to_array(["name" =>                 // line 71
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 71, $this->source); })()), "value" =>                 // line 72
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 72, $this->source); })()), "disabled" =>                 // line 73
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 73, $this->source); })())]));
                break;
            }
            case "lightswitch":
            {
                // line 76
                $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms/editableTable", 76)->display(twig_to_array(["name" =>                 // line 77
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 77, $this->source); })()), "on" =>                 // line 78
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 78, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 79
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "small" => true, "disabled" =>                 // line 81
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 81, $this->source); })())]));
                // line 83
                echo "                                    ";
                break;
            }
            case "select":
            {
                // line 84
                $this->loadTemplate("_includes/forms/select", "_includes/forms/editableTable", 84)->display(twig_to_array(["class" => "small", "name" =>                 // line 86
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 86, $this->source); })()), "options" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 87
($context["cell"] ?? null), "options", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 87, $this->source); })()), "options", []))), "value" =>                 // line 88
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 88, $this->source); })()), "disabled" =>                 // line 89
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 89, $this->source); })())]));
                break;
            }
            case "time":
            {
                // line 92
                $this->loadTemplate("_includes/forms/time", "_includes/forms/editableTable", 92)->display(twig_to_array(["name" =>                 // line 93
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 93, $this->source); })()), "value" =>                 // line 94
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 94, $this->source); })()), "disabled" =>                 // line 95
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 95, $this->source); })())]));
                break;
            }
            case "email":
            case "url":
            {
                // line 98
                $this->loadTemplate("_includes/forms/text", "_includes/forms/editableTable", 98)->display(twig_to_array(["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 99
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 99, $this->source); })()), "type", []), "name" =>                 // line 100
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 100, $this->source); })()), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 101
($context["col"] ?? null), "placeholder", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])) : (null)), "value" =>                 // line 102
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 102, $this->source); })()), "disabled" =>                 // line 103
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 103, $this->source); })())]));
                break;
            }
            case "template":
            {
                // line 106
                $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms/editableTable", 106)->display(twig_to_array(["name" =>                 // line 107
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 107, $this->source); })()), "suggestions" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                 // line 108
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 108, $this->source); })()), "cp", []), "getTemplateSuggestions", [], "method"), "value" =>                 // line 109
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 109, $this->source); })()), "disabled" =>                 // line 110
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 110, $this->source); })())]));
                break;
            }
            default:
            {
                // line 113
                echo "<textarea name=\"";
                echo twig_escape_filter($this->env, (isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 113, $this->source); })()), "html", null, true);
                echo "\" rows=\"1\"";
                if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 113, $this->source); })())) {
                    echo " disabled";
                }
                if (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", true, true)) {
                    echo " placeholder=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 113, $this->source); })()), "placeholder", []), "html", null, true);
                    echo "\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 113, $this->source); })()), "html", null, true);
                echo "</textarea>";
            }
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/editableTable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  421 => 113,  415 => 110,  414 => 109,  413 => 108,  412 => 107,  411 => 106,  405 => 103,  404 => 102,  403 => 101,  402 => 100,  401 => 99,  400 => 98,  393 => 95,  392 => 94,  391 => 93,  390 => 92,  384 => 89,  383 => 88,  382 => 87,  381 => 86,  380 => 84,  374 => 83,  372 => 81,  371 => 79,  370 => 78,  369 => 77,  368 => 76,  362 => 73,  361 => 72,  360 => 71,  359 => 70,  353 => 67,  352 => 65,  351 => 64,  350 => 63,  344 => 60,  343 => 59,  342 => 58,  341 => 57,  340 => 56,  336 => 54,  332 => 53,  323 => 141,  319 => 140,  315 => 139,  311 => 138,  302 => 137,  299 => 136,  296 => 135,  293 => 134,  290 => 133,  287 => 132,  285 => 131,  282 => 130,  276 => 128,  274 => 127,  270 => 125,  263 => 123,  260 => 122,  254 => 121,  249 => 120,  246 => 119,  232 => 118,  228 => 116,  226 => 53,  201 => 52,  198 => 51,  195 => 50,  192 => 49,  189 => 48,  181 => 46,  179 => 45,  172 => 44,  169 => 43,  166 => 42,  163 => 41,  146 => 40,  141 => 39,  137 => 38,  132 => 35,  126 => 33,  123 => 32,  116 => 30,  111 => 28,  109 => 27,  103 => 26,  99 => 25,  94 => 23,  88 => 21,  84 => 19,  80 => 18,  71 => 15,  68 => 14,  65 => 13,  59 => 11,  57 => 10,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set static = static ?? false %}
{%- set cols = cols ?? [] %}
{%- set rows = rows ?? [] %}
{%- set initJs = not static and (initJs ?? true) -%}
{%- set minRows = minRows ?? null %}
{%- set maxRows = maxRows ?? null %}
{%- set staticRows = static or (staticRows ?? false) or (minRows == 1 and maxRows == 1 and rows|length == 1) %}
{%- set fixedRows = not staticRows and (minRows and minRows == maxRows and minRows == rows|length) %}

{% if not static %}
    <input type=\"hidden\" name=\"{{ name }}\" value=\"\">
{% endif %}

<table id=\"{{ id }}\" class=\"shadow-box editable\"
       {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    <thead>
        <tr>
            {% for col in cols %}
                {%- switch col.type %}
                    {%- case 'time' %}
                        {%- do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') %}
                    {%- case 'template' %}
                        {%- do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}
                {%- endswitch %}
                <th scope=\"col\" class=\"{{ col.class ?? '' }}\">
                    {%- if col.heading is defined and col.heading %}{{ col.heading }}{% else %}&nbsp;{% endif %}
                    {%- if col.info is defined -%}
                        <span class=\"info\">{{ col.info|md|raw }}</span>
                    {%- endif -%}
                </th>
            {% endfor %}
            {% if not staticRows %}
                <th colspan=\"{{ fixedRows ? 1 : 2 }}\"></th>
            {% endif %}
        </tr>
    </thead>
    <tbody>
        {% for rowId, row in rows %}
            <tr data-id=\"{{ rowId }}\">
                {% for colId, col in cols %}
                    {% set cell = row[colId] ?? null %}
                    {% set value = cell.value is defined ? cell.value : cell %}
                    {% if col.type == 'heading' %}
                        <th scope=\"row\" class=\"{{ cell.class ?? col.class ?? '' }}\">{{ value|raw }}</th>
                    {% elseif col.type == 'html' %}
                        <td class=\"{{ cell.class ?? col.class ?? '' }}\">{{ value|raw }}</td>
                    {% else %}
                        {% set hasErrors = cell.hasErrors ?? false %}
                        {% set cellName = name~'['~rowId~']['~colId~']' %}
                        {% set textual = (col.type in ['color', 'date', 'email', 'multiline', 'number', 'singleline', 'template', 'time', 'url']) %}
                        {% set isCode = col.code is defined or col.type == 'color' %}
                        <td class=\"{% if textual %}textual{% endif %} {% if col.class is defined %}{{ col.class }}{% endif %} {% if isCode %}code{% endif %} {% if hasErrors %}error{% endif %}\"{% if col.width is defined %} width=\"{{ col.width }}\"{% endif %}>
                            {% block tablecell %}
                                {%- switch col.type -%}
                                    {%- case 'checkbox' -%}
                                        {% include \"_includes/forms/checkbox\" with {
                                            name: cellName,
                                            value:  col.value ?? 1,
                                            checked: value is not empty,
                                            disabled: static
                                        } only %}
                                    {%- case 'color' -%}
                                        {% include \"_includes/forms/color\" with {
                                            name: cellName,
                                            value: value,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {%- case 'date' -%}
                                        {% include \"_includes/forms/date\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'lightswitch' -%}
                                        {% include \"_includes/forms/lightswitch\" with {
                                            name: cellName,
                                            on: value,
                                            value: col.value ?? 1,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {% case 'select' -%}
                                        {% include \"_includes/forms/select\" with {
                                            class: 'small',
                                            name: cellName,
                                            options: cell.options ?? col.options,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'time' -%}
                                        {% include \"_includes/forms/time\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'email' or 'url' -%}
                                        {% include \"_includes/forms/text\" with {
                                            type: col.type,
                                            name: cellName,
                                            placeholder: col.placeholder ?? null,
                                            value:  value,
                                            disabled: static
                                        } only %}
                                    {%- case 'template' -%}
                                        {% include \"_includes/forms/autosuggest\" with {
                                            name: cellName,
                                            suggestions: craft.cp.getTemplateSuggestions(),
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- default -%}
                                        <textarea name=\"{{ cellName }}\" rows=\"1\"{% if static %} disabled{% endif %}{% if col.placeholder is defined %} placeholder=\"{{ col.placeholder }}\"{% endif %}>{{ value }}</textarea>
                                {%- endswitch -%}
                            {% endblock %}
                        </td>
                    {% endif %}
                {% endfor %}
                {% if not staticRows %}
                    <td class=\"thin action\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\"></a></td>
                    {% if not fixedRows %}<td class=\"thin action\"><a class=\"delete icon\" title=\"{{ 'Delete'|t('app') }}\"></a></td>{% endif %}
                {% endif %}
            </tr>
        {% endfor %}
    </tbody>
</table>
{% if not staticRows and not fixedRows %}
    <div class=\"btn add icon\">{{ addRowLabel is defined ? addRowLabel : \"Add a row\"|t('app') }}</div>
{% endif %}

{% if initJs %}
    {% set jsId = id|namespaceInputId|e('js') %}
    {% set jsName = name|namespaceInputName|e('js') %}
    {% set jsCols = cols|json_encode %}
    {% set defaultValues = defaultValues ?? null %}
    {% js %}
        new Craft.EditableTable(\"{{ jsId }}\", \"{{ jsName }}\", {{ jsCols|raw }}, {
            defaultValues: {{ defaultValues ? defaultValues|json_encode|raw : '{}' }},
            staticRows: {{ staticRows ? 'true' : 'false' }},
            minRows: {{ minRows ? minRows : 'null' }},
            maxRows: {{ maxRows ? maxRows : 'null' }}
        });
    {% endjs %}
{% endif %}
", "_includes/forms/editableTable", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/vendor/craftcms/cms/src/templates/_includes/forms/editableTable.html");
    }
}
