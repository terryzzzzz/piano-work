<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _special/install/db */
class __TwigTemplate_f1c16e13075859c9b9d209f7200348a29125977b33926b50d4852c1084e29751 extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_special/install/db", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        $context["dbConfig"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "config", []), "db", []);
        // line 4
        echo "
<div id=\"db\" class=\"screen hidden\" data-inputs=\"driver,server,port,user,password,database,schema,tablePrefix\">
    <div class=\"icon\">";
        // line 6
        echo (isset($context["dbIcon"]) || array_key_exists("dbIcon", $context) ? $context["dbIcon"] : (function () { throw new RuntimeError('Variable "dbIcon" does not exist.', 6, $this->source); })());
        echo "</div>
    <h1>";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Connect the database", "app"), "html", null, true);
        echo "</h1>

    <form accept-charset=\"UTF-8\">
        ";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "

        <div class=\"flex field first\">
            <div>
                ";
        // line 14
        echo twig_call_macro($macros["forms"], "macro_selectField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Driver", "app"), "id" => "db-driver", "options" => [0 => ["label" => "MySQL", "value" => "mysql"], 1 => ["label" => "PostgreSQL", "value" => "pgsql"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 22
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 22, $this->source); })()), "driver", []), "toggle" => true, "targetPrefix" => ".db-"]], 14, $context, $this->getSourceContext());
        // line 25
        echo "
            </div>
            <div class=\"flex-grow\">
                ";
        // line 28
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Server", "app"), "id" => "db-server", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 31, $this->source); })()), "server", []) != "localhost")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 31, $this->source); })()), "server", [])) : ("")), "placeholder" => "localhost"]], 28, $context, $this->getSourceContext());
        // line 33
        echo "
            </div>
            <div>
                ";
        // line 36
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Port", "app"), "id" => "db-port", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 39
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 39, $this->source); })()), "port", []), "size" => 7]], 36, $context, $this->getSourceContext());
        // line 41
        echo "
            </div>
        </div>

        <div class=\"flex field\">
            <div class=\"flex-grow\">
                ";
        // line 47
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Username", "app"), "id" => "db-user", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 50
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 50, $this->source); })()), "user", []) != "root")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 50, $this->source); })()), "user", [])) : ("")), "placeholder" => "root"]], 47, $context, $this->getSourceContext());
        // line 52
        echo "
            </div>
            <div class=\"flex-grow\">
                ";
        // line 55
        echo twig_call_macro($macros["forms"], "macro_passwordField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "id" => "db-password", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 58
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 58, $this->source); })()), "password", [])]], 55, $context, $this->getSourceContext());
        // line 59
        echo "
            </div>
        </div>

        <div class=\"flex field\">
            <div class=\"flex-grow\">
                ";
        // line 65
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Database Name", "app"), "id" => "db-database", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 68
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 68, $this->source); })()), "database", [])]], 65, $context, $this->getSourceContext());
        // line 69
        echo "
            </div>
            <div class=\"flex-grow db-pgsql";
        // line 71
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 71, $this->source); })()), "driver", []) != "pgsql")) {
            echo " hidden";
        }
        echo "\">
                ";
        // line 72
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Schema Name", "app"), "id" => "db-schema", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 75
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 75, $this->source); })()), "schema", []) != "public")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 75, $this->source); })()), "schema", [])) : ("")), "placeholder" => "public"]], 72, $context, $this->getSourceContext());
        // line 77
        echo "
            </div>
            <div>
                ";
        // line 80
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => ((($this->extensions['craft\web\twig\Extension']->translateFilter("Prefix", "app") . " <span class='info'>") . $this->extensions['craft\web\twig\Extension']->translateFilter("The table name prefix", "app")) . "</span>"), "id" => "db-tablePrefix", "value" => twig_trim_filter(craft\helpers\Template::attribute($this->env, $this->source,         // line 83
(isset($context["dbConfig"]) || array_key_exists("dbConfig", $context) ? $context["dbConfig"] : (function () { throw new RuntimeError('Variable "dbConfig" does not exist.', 83, $this->source); })()), "tablePrefix", []), "_"), "maxlength" => 5, "size" => 7]], 80, $context, $this->getSourceContext());
        // line 86
        echo "
            </div>
        </div>

        <div class=\"buttons\">
            <div class=\"btn big submit\">";
        // line 91
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Next", "app"), "html", null, true);
        echo "
                <input type=\"submit\" tabindex=\"-1\">
            </div>
        </div>
    </form>
</div>
";
    }

    public function getTemplateName()
    {
        return "_special/install/db";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 91,  135 => 86,  133 => 83,  132 => 80,  127 => 77,  125 => 75,  124 => 72,  118 => 71,  114 => 69,  112 => 68,  111 => 65,  103 => 59,  101 => 58,  100 => 55,  95 => 52,  93 => 50,  92 => 47,  84 => 41,  82 => 39,  81 => 36,  76 => 33,  74 => 31,  73 => 28,  68 => 25,  66 => 22,  65 => 14,  58 => 10,  52 => 7,  48 => 6,  44 => 4,  42 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% set dbConfig = craft.app.config.db %}

<div id=\"db\" class=\"screen hidden\" data-inputs=\"driver,server,port,user,password,database,schema,tablePrefix\">
    <div class=\"icon\">{{ dbIcon|raw }}</div>
    <h1>{{ \"Connect the database\"|t('app') }}</h1>

    <form accept-charset=\"UTF-8\">
        {{ csrfInput() }}

        <div class=\"flex field first\">
            <div>
                {{ forms.selectField({
                    first: true,
                    label: \"Driver\"|t('app'),
                    id: 'db-driver',
                    options: [
                        { label: 'MySQL', value: 'mysql' },
                        { label: 'PostgreSQL', value: 'pgsql' }
                    ],
                    value: dbConfig.driver,
                    toggle: true,
                    targetPrefix: '.db-',
                }) }}
            </div>
            <div class=\"flex-grow\">
                {{ forms.textField({
                    label: \"Server\"|t('app'),
                    id: 'db-server',
                    value: dbConfig.server != 'localhost' ? dbConfig.server,
                    placeholder: 'localhost'
                }) }}
            </div>
            <div>
                {{ forms.textField({
                    label: \"Port\"|t('app'),
                    id: 'db-port',
                    value: dbConfig.port,
                    size: 7
                }) }}
            </div>
        </div>

        <div class=\"flex field\">
            <div class=\"flex-grow\">
                {{ forms.textField({
                    label: \"Username\"|t('app'),
                    id: 'db-user',
                    value: dbConfig.user != 'root' ? dbConfig.user,
                    placeholder: 'root'
                }) }}
            </div>
            <div class=\"flex-grow\">
                {{ forms.passwordField({
                    label: \"Password\"|t('app'),
                    id: 'db-password',
                    value: dbConfig.password
                }) }}
            </div>
        </div>

        <div class=\"flex field\">
            <div class=\"flex-grow\">
                {{ forms.textField({
                    label: \"Database Name\"|t('app'),
                    id: 'db-database',
                    value: dbConfig.database
                }) }}
            </div>
            <div class=\"flex-grow db-pgsql{% if dbConfig.driver != 'pgsql' %} hidden{% endif %}\">
                {{ forms.textField({
                    label: \"Schema Name\"|t('app'),
                    id: 'db-schema',
                    value: dbConfig.schema != 'public' ? dbConfig.schema,
                    placeholder: 'public'
                }) }}
            </div>
            <div>
                {{ forms.textField({
                    label: \"#{'Prefix'|t('app')} <span class='info'>#{'The table name prefix'|t('app')}</span>\",
                    id: 'db-tablePrefix',
                    value: dbConfig.tablePrefix|trim('_'),
                    maxlength: 5,
                    size: 7
                }) }}
            </div>
        </div>

        <div class=\"buttons\">
            <div class=\"btn big submit\">{{ \"Next\"|t('app') }}
                <input type=\"submit\" tabindex=\"-1\">
            </div>
        </div>
    </form>
</div>
", "_special/install/db", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/vendor/craftcms/cms/src/templates/_special/install/db.html");
    }
}
