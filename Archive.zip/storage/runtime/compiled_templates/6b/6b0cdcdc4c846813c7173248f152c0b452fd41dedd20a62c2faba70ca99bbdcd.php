<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home */
class __TwigTemplate_4198f3e1b40d6eb0479f17761de5862334c78cfac4bd3b1943f685a200ca4874 extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<h1>Hello World!</h1>
<p>Here is a sub heading.</p>
";
    }

    public function getTemplateName()
    {
        return "home";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<h1>Hello World!</h1>
<p>Here is a sub heading.</p>
", "home", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/templates/home.twig");
    }
}
