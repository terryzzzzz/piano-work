<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_edit */
class __TwigTemplate_f2529d57f16e7fb38b5dd4daf528bfc45e8eb2b0c1d40d061788da205a94fa52 extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sections/_edit", 4)->unwrap();
        // line 198
        ob_start();
        // line 199
        echo "    var \$siteRows = \$('#sites').children('tbody').children(),
        \$lightswitches = \$siteRows.children('th:nth-child(2)').children('.lightswitch');

    function updateSites() {
        \$lightswitches.each(function() {
            if (\$(this).data('lightswitch').on) {
                \$(this).parent().nextAll('td').removeClass('disabled').find('textarea,div.lightswitch,input').attr('tabindex', '0');
            } else {
                \$(this).parent().nextAll('td').addClass('disabled').find('textarea,div.lightswitch,input').attr('tabindex', '-1');
            }
        });
    }

    \$lightswitches.on('change', updateSites);

    Garnish.\$doc.ready(function() {
        updateSites();
    });

    ";
        // line 218
        if ((isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 218, $this->source); })())) {
            // line 219
            echo "        new Craft.HandleGenerator('#name', '#handle');

        ";
            // line 221
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 221, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 222
                echo "            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 223
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 224
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 226
            echo "    ";
        }
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "    <input type=\"hidden\" name=\"action\" value=\"sections/save-section\">
    ";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->redirectInputFunction("settings/sections"), "html", null, true);
        echo "

    ";
        // line 11
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 11, $this->source); })()), "id", [])) {
            echo "<input type=\"hidden\" name=\"sectionId\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 11, $this->source); })()), "id", []), "html", null, true);
            echo "\">";
        }
        // line 12
        echo "
    ";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this section will be called in the CP.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 19
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 19, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 20, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 13, $context, $this->getSourceContext());
        // line 23
        echo "

    ";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this section in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 33
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 33, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 34
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 34, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 25, $context, $this->getSourceContext());
        // line 36
        echo "

    ";
        // line 38
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable versioning for entries in this section?", "app"), "id" => "enableVersioning", "name" => "enableVersioning", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 42
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 42, $this->source); })()), "enableVersioning", [])]], 38, $context, $this->getSourceContext());
        // line 43
        echo "

    ";
        // line 45
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section Type", "app"), "instructions" => ($this->extensions['craft\web\twig\Extension']->translateFilter("What type of section is this?", "app") . ((craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 47, $this->source); })()), "id", [])) ? ((("<br><span class=\"error\">" . $this->extensions['craft\web\twig\Extension']->translateFilter("Careful—changing this may result in data loss.", "app")) . "</span>")) : (""))), "id" => "type", "name" => "type", "options" =>         // line 50
(isset($context["typeOptions"]) || array_key_exists("typeOptions", $context) ? $context["typeOptions"] : (function () { throw new RuntimeError('Variable "typeOptions" does not exist.', 50, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 51
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 51, $this->source); })()), "type", []), "toggle" => true, "targetPrefix" => ".type-", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 54, $this->source); })()), "getErrors", [0 => "type"], "method")]], 45, $context, $this->getSourceContext());
        // line 55
        echo "

    <hr>

    ";
        // line 59
        $context["siteRows"] = [];
        // line 60
        echo "    ";
        $context["siteErrors"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 60, $this->source); })()), "getErrors", [0 => "siteSettings"], "method");
        // line 61
        echo "
    ";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 62, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 63
            echo "        ";
            $context["siteSettings"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")) : (null));
            // line 64
            echo "        ";
            if ((isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 64, $this->source); })())) {
                // line 65
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 65, $this->source); })()), "getErrors", [], "method"));
                foreach ($context['_seq'] as $context["attribute"] => $context["errors"]) {
                    // line 66
                    echo "                ";
                    $context["siteErrors"] = twig_array_merge((isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 66, $this->source); })()), $context["errors"]);
                    // line 67
                    echo "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['attribute'], $context['errors'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 68
                echo "        ";
            }
            // line 69
            echo "        ";
            $context["siteRows"] = twig_array_merge((isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 69, $this->source); })()), [craft\helpers\Template::attribute($this->env, $this->source,             // line 70
$context["site"], "handle", []) => ["heading" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 71
$context["site"], "name", []), "site")), "enabled" => twig_include($this->env, $context, "_includes/forms/lightswitch", ["name" => (("sites[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 73
$context["site"], "handle", [])) . "][enabled]"), "on" => (            // line 74
(isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 74, $this->source); })()) || (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 74, $this->source); })())), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 75
$context["site"], "id", []), "small" => true]), "singleUri" => ["value" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 79
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 79, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 79, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 79, $this->source); })()), "uriFormat", []) != "__home__"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 79, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 80
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 80, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 80, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 80, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "uriFormat" => ["value" => ((            // line 83
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 83, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 83, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 84
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 84, $this->source); })()), "type", []) != "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 84, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 84, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "template" => ["value" => ((            // line 87
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 87, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 87, $this->source); })()), "template", [])) : ("")), "hasErrors" => ((            // line 88
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 88, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 88, $this->source); })()), "hasErrors", [0 => "template"], "method")) : (""))], "enabledByDefault" => ((            // line 90
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 90, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 90, $this->source); })()), "enabledByDefault", [])) : (true))]]);
            // line 93
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "
    ";
        // line 95
        echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Settings", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose which sites this section should be available in, and configure the site-specific settings.", "app"), "id" => "sites", "name" => "sites", "cols" => ["heading" => ["type" => "heading", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "class" => "thin"], "enabled" => ["type" => "heading", "class" => ("thin" . (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 108
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 108, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? (" hidden") : ("")))], "singleUri" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URI", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the entry URI should be for the site. Leave blank if this is the homepage.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if this is the homepage", "app"), "code" => true, "class" => ("type-single" . (((craft\helpers\Template::attribute($this->env, $this->source,         // line 116
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 116, $this->source); })()), "type", []) != "single")) ? (" hidden") : ("")))], "uriFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry URI Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What entry URIs should look like for the site. Leave blank if entries don’t have URLs.", "app"), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Leave blank if entries don’t have URLs", "app"), "code" => true, "class" => ("type-channel type-structure" . (((craft\helpers\Template::attribute($this->env, $this->source,         // line 124
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 124, $this->source); })()), "type", []) == "single")) ? (" hidden") : ("")))], "template" => ["type" => "template", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which template should be loaded when an entry’s URL is requested.", "app"), "code" => true], "enabledByDefault" => ["type" => "lightswitch", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Status", "app"), "class" => ("thin type-channel type-structure" . (((craft\helpers\Template::attribute($this->env, $this->source,         // line 135
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 135, $this->source); })()), "type", []) == "single")) ? (" hidden") : ("")))]], "rows" =>         // line 138
(isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 138, $this->source); })()), "staticRows" => true, "errors" => array_unique(        // line 140
(isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 140, $this->source); })()))]], 95, $context, $this->getSourceContext());
        // line 141
        echo "

    ";
        // line 143
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 143, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 144
            echo "        <div class=\"field type-channel type-structure ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 144, $this->source); })()), "type", []) == "single")) {
                echo "hidden";
            }
            echo "\">
            ";
            // line 145
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Of the enabled sites above, which sites should entries in this section be saved to?", "app"), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save entries to the site they were created in", "app")], 1 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites in the same site group", "app")], 2 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites with the same language", "app")], 3 => ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to all sites enabled for this section", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 156
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 156, $this->source); })()), "propagationMethod", [])]], 145, $context, $this->getSourceContext());
            // line 157
            echo "
        </div>
    ";
        }
        // line 160
        echo "
    <div class=\"field type-structure ";
        // line 161
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 161, $this->source); })()), "type", []) != "structure")) {
            echo "hidden";
        }
        echo "\">
        ";
        // line 162
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Levels", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of levels this section can have. Leave blank if you don’t care.", "app"), "id" => "maxLevels", "name" => "maxLevels", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 167
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 167, $this->source); })()), "maxLevels", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 169
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 169, $this->source); })()), "getErrors", [0 => "maxLevels"], "method")]], 162, $context, $this->getSourceContext());
        // line 170
        echo "
    </div>

    ";
        // line 173
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 173, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 173, $this->source); })()))) {
            // line 174
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Preview Targets", "app"), "instructions" => "Additional locations that should be available for previewing entries in this section.", "id" => "previewTargets", "name" => "previewTargets", "cols" => ["label" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Label", "app")], "urlFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL/URI to use for this target.", "app"), "code" => true]], "rows" => craft\helpers\Template::attribute($this->env, $this->source,             // line 191
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 191, $this->source); })()), "previewTargets", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 192
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 192, $this->source); })()), "getErrors", [0 => "previewTargets"], "method")]], 174, $context, $this->getSourceContext());
            // line 193
            echo "
    ";
        }
    }

    public function getTemplateName()
    {
        return "settings/sections/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  295 => 193,  293 => 192,  292 => 191,  290 => 174,  288 => 173,  283 => 170,  281 => 169,  280 => 167,  279 => 162,  273 => 161,  270 => 160,  265 => 157,  263 => 156,  262 => 145,  255 => 144,  253 => 143,  249 => 141,  247 => 140,  246 => 138,  245 => 135,  244 => 124,  243 => 116,  242 => 108,  241 => 95,  238 => 94,  224 => 93,  222 => 90,  221 => 88,  220 => 87,  219 => 84,  218 => 83,  217 => 80,  216 => 79,  215 => 75,  214 => 74,  213 => 73,  212 => 71,  211 => 70,  209 => 69,  206 => 68,  200 => 67,  197 => 66,  192 => 65,  189 => 64,  186 => 63,  169 => 62,  166 => 61,  163 => 60,  161 => 59,  155 => 55,  153 => 54,  152 => 51,  151 => 50,  150 => 47,  149 => 45,  145 => 43,  143 => 42,  142 => 38,  138 => 36,  136 => 34,  135 => 33,  134 => 25,  130 => 23,  128 => 20,  127 => 19,  126 => 13,  123 => 12,  117 => 11,  112 => 9,  109 => 8,  105 => 7,  100 => 1,  96 => 226,  88 => 224,  84 => 223,  79 => 222,  75 => 221,  71 => 219,  69 => 218,  48 => 199,  46 => 198,  44 => 4,  42 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"sections/save-section\">
    {{ redirectInput('settings/sections') }}

    {% if section.id %}<input type=\"hidden\" name=\"sectionId\" value=\"{{ section.id }}\">{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this section will be called in the CP.\"|t('app'),
        id: 'name',
        name: 'name',
        value: section.name,
        errors: section.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {{ forms.textField({
        label: \"Handle\"|t('app'),
        instructions: \"How you’ll refer to this section in the templates.\"|t('app'),
        id: 'handle',
        name: 'handle',
        class: 'code',
        autocorrect: false,
        autocapitalize: false,
        value: section.handle,
        errors: section.getErrors('handle'),
        required: true
    }) }}

    {{ forms.checkboxField({
        label: \"Enable versioning for entries in this section?\"|t('app'),
        id: 'enableVersioning',
        name: 'enableVersioning',
        checked: section.enableVersioning
    }) }}

    {{ forms.selectField({
        label: \"Section Type\"|t('app'),
        instructions: \"What type of section is this?\"|t('app') ~ (section.id ? '<br><span class=\"error\">'~\"Careful—changing this may result in data loss.\"|t('app')~'</span>' : ''),
        id: 'type',
        name: 'type',
        options: typeOptions,
        value: section.type,
        toggle: true,
        targetPrefix: '.type-',
        errors: section.getErrors('type')
    }) }}

    <hr>

    {% set siteRows = [] %}
    {% set siteErrors = section.getErrors('siteSettings') %}

    {% for site in craft.app.sites.getAllSites() %}
        {% set siteSettings = section.siteSettings[site.id] ?? null %}
        {% if siteSettings %}
            {% for attribute, errors in siteSettings.getErrors() %}
                {% set siteErrors = siteErrors|merge(errors) %}
            {% endfor %}
        {% endif %}
        {% set siteRows = siteRows|merge({
            (site.handle): {
                heading: site.name|t('site')|e,
                enabled: include('_includes/forms/lightswitch', {
                    name: 'sites['~site.handle~'][enabled]',
                    on: brandNewSection or siteSettings,
                    value: site.id,
                    small: true
                }),
                singleUri: {
                    value: (section.type == 'single' and siteSettings and siteSettings.uriFormat != '__home__') ? siteSettings.uriFormat,
                    hasErrors: (section.type == 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                uriFormat: {
                    value: siteSettings ? siteSettings.uriFormat,
                    hasErrors: (section.type != 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                template: {
                    value: siteSettings ? siteSettings.template,
                    hasErrors: siteSettings ? siteSettings.hasErrors('template'),
                },
                enabledByDefault: siteSettings ? siteSettings.enabledByDefault : true,
            }
        }) %}
    {% endfor %}

    {{ forms.editableTableField({
        label: \"Site Settings\"|t('app'),
        instructions: \"Choose which sites this section should be available in, and configure the site-specific settings.\"|t('app'),
        id: 'sites',
        name: 'sites',
        cols: {
            heading: {
                type: 'heading',
                heading: \"Site\"|t('app'),
                class: 'thin'
            },
            enabled: {
                type: 'heading',
                class: 'thin'~(not craft.app.getIsMultiSite() ? ' hidden')
            },
            singleUri: {
                type: 'singleline',
                heading: \"URI\"|t('app'),
                info: \"What the entry URI should be for the site. Leave blank if this is the homepage.\"|t('app'),
                placeholder: \"Leave blank if this is the homepage\"|t('app'),
                code: true,
                class: 'type-single'~(section.type != 'single' ? ' hidden')
            },
            uriFormat: {
                type: 'singleline',
                heading: \"Entry URI Format\"|t('app'),
                info: \"What entry URIs should look like for the site. Leave blank if entries don’t have URLs.\"|t('app'),
                placeholder: \"Leave blank if entries don’t have URLs\"|t('app'),
                code: true,
                class: 'type-channel type-structure'~(section.type == 'single' ? ' hidden')
            },
            template: {
                type: 'template',
                heading: \"Template\"|t('app'),
                info: \"Which template should be loaded when an entry’s URL is requested.\"|t('app'),
                code: true
            },
            enabledByDefault: {
                type: 'lightswitch',
                heading: \"Default Status\"|t('app'),
                class: 'thin type-channel type-structure'~(section.type == 'single' ? ' hidden')
            }
        },
        rows: siteRows,
        staticRows: true,
        errors: siteErrors|unique
    }) }}

    {% if craft.app.getIsMultiSite() %}
        <div class=\"field type-channel type-structure {% if section.type == 'single' %}hidden{% endif %}\">
            {{ forms.selectField({
                label: 'Propagation Method'|t('app'),
                instructions: 'Of the enabled sites above, which sites should entries in this section be saved to?'|t('app'),
                id: 'propagationMethod',
                name: 'propagationMethod',
                options: [
                    { value: 'none', label: 'Only save entries to the site they were created in'|t('app') },
                    { value: 'siteGroup', label: 'Save entries to other sites in the same site group'|t('app') },
                    { value: 'language', label: 'Save entries to other sites with the same language'|t('app') },
                    { value: 'all', label: 'Save entries to all sites enabled for this section'|t('app') },
                ],
                value: section.propagationMethod
            }) }}
        </div>
    {% endif %}

    <div class=\"field type-structure {% if section.type != 'structure' %}hidden{% endif %}\">
        {{ forms.textField({
            label: \"Max Levels\"|t('app'),
            instructions: \"The maximum number of levels this section can have. Leave blank if you don’t care.\"|t('app'),
            id: 'maxLevels',
            name: 'maxLevels',
            value: section.maxLevels,
            size: 5,
            errors: section.getErrors('maxLevels')
        }) }}
    </div>

    {% if CraftEdition == CraftPro %}
        {{ forms.editableTableField({
            label: 'Preview Targets'|t('app'),
            instructions: 'Additional locations that should be available for previewing entries in this section.',
            id: 'previewTargets',
            name: 'previewTargets',
            cols: {
                label: {
                    type: 'singleline',
                    heading: 'Label'|t('app'),
                },
                urlFormat: {
                    type: 'singleline',
                    heading: 'URL Format'|t('app'),
                    info: 'The URL/URI to use for this target.'|t('app'),
                    code: true,
                }
            },
            rows: section.previewTargets,
            errors: section.getErrors('previewTargets')
        }) }}
    {% endif %}
{% endblock %}


{% js %}
    var \$siteRows = \$('#sites').children('tbody').children(),
        \$lightswitches = \$siteRows.children('th:nth-child(2)').children('.lightswitch');

    function updateSites() {
        \$lightswitches.each(function() {
            if (\$(this).data('lightswitch').on) {
                \$(this).parent().nextAll('td').removeClass('disabled').find('textarea,div.lightswitch,input').attr('tabindex', '0');
            } else {
                \$(this).parent().nextAll('td').addClass('disabled').find('textarea,div.lightswitch,input').attr('tabindex', '-1');
            }
        });
    }

    \$lightswitches.on('change', updateSites);

    Garnish.\$doc.ready(function() {
        updateSites();
    });

    {% if brandNewSection %}
        new Craft.HandleGenerator('#name', '#handle');

        {% for site in craft.app.sites.getAllSites() %}
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        {% endfor %}
    {% endif %}
{% endjs %}
", "settings/sections/_edit", "/Users/Ter2yzzZ/Documents/X-File/Naomi Portfolio/code/vendor/craftcms/cms/src/templates/settings/sections/_edit.html");
    }
}
