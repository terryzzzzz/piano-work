<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e */
class __TwigTemplate_87c87f9cb05df87abaa83e233480a50c634dfbe6530f043b301a684d7e1cb847 extends \craft\web\twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "section", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "section", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "section", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new RuntimeError('Variable "object" does not exist.', 1, $this->source); })()), "section", []))), "name", []);
    }

    public function getTemplateName()
    {
        return "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ (_variables.section ?? object.section).name|raw|raw }}", "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e", "");
    }
}
